#	Start

Before using the plugin, you need to enable plugin: "NNERuntimeORT" in Unreal Engine and restart.

# Demo

- Open the level Demo in /Content/
- Run it
- Follow the tip in the top left corner of the screen

- Now you should see a canvas, draw your sketch and click on the button "Run" below, the bottom left should show the category(class) you drew, and the bottom right should show the score of your painting in the current prompt category.

### Now, with this cool plugin feature, your game design possibilities are just about to get a whole lot more awesome! Get ready to add a sprinkle of creativity and a dash of fun to your game content in a zillion different scenarios.