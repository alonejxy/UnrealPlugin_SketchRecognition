//Copyright (c) Code By HelloJXY. All rights reserved. Date : 2024/6/20

#include "sketch_recognize.h"

#define LOCTEXT_NAMESPACE "Fsketch_recognizeModule"

void Fsketch_recognizeModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
}

void Fsketch_recognizeModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(Fsketch_recognizeModule, sketch_recognize)