//Copyright (c) Code By HelloJXY. All rights reserved. Date : 2024/6/20

#include "Main_sketch_recognize.h"

UMain_sketch_recognize::UMain_sketch_recognize()
{
	FString classinit[] = { "The Eiffel Tower", "The Great Wall of China", "The Mona Lisa", "aircraft carrier", "airplane", "alarm clock", "ambulance", "angel", "animal migration", "ant", "anvil", "apple", "arm", "asparagus", "axe", "backpack", "banana", "bandage", "barn", "baseball", "baseball bat", "basket", "basketball", "bat", "bathtub", "beach", "bear", "beard", "bed", "bee", "belt", "bench", "bicycle", "binoculars", "bird", "birthday cake", "blackberry", "blueberry", "book", "boomerang", "bottlecap", "bowtie", "bracelet", "brain", "bread", "bridge", "broccoli", "broom", "bucket", "bulldozer", "bus", "bush", "butterfly", "cactus", "cake", "calculator", "calendar", "camel", "camera", "camouflage", "campfire", "candle", "cannon", "canoe", "car", "carrot", "castle", "cat", "ceiling fan", "cell phone", "cello", "chair", "chandelier", "church", "circle", "clarinet", "clock", "cloud", "coffee cup", "compass", "computer", "cookie", "cooler", "couch", "cow", "crab", "crayon", "crocodile", "crown", "cruise ship", "cup", "diamond", "dishwasher", "diving board", "dog", "dolphin", "donut", "door", "dragon", "dresser", "drill", "drums", "duck", "dumbbell", "ear", "elbow", "elephant", "envelope", "eraser", "eye", "eyeglasses", "face", "fan", "feather", "fence", "finger", "fire hydrant", "fireplace", "firetruck", "fish", "flamingo", "flashlight", "flip flops", "floor lamp", "flower", "flying saucer", "foot", "fork", "frog", "frying pan", "garden", "garden hose", "giraffe", "goatee", "golf club", "grapes", "grass", "guitar", "hamburger", "hammer", "hand", "harp", "hat", "headphones", "hedgehog", "helicopter", "helmet", "hexagon", "hockey puck", "hockey stick", "horse", "hospital", "hot air balloon", "hot dog", "hot tub", "hourglass", "house", "house plant", "hurricane", "ice cream", "jacket", "jail", "kangaroo", "key", "keyboard", "knee", "knife", "ladder", "lantern", "laptop", "leaf", "leg", "light bulb", "lighter", "lighthouse", "lightning", "lion", "lipstick", "lobster", "lollipop", "mailbox", "map", "marker", "matches", "megaphone", "mermaid", "microphone", "microwave", "monkey", "moon", "mosquito", "motorbike", "mountain", "mouse", "moustache", "mouth", "mug", "mushroom", "nail", "necklace", "nose", "ocean", "octagon", "octopus", "onion", "oven", "owl", "paint can", "paintbrush", "palm tree", "panda", "pants", "paper clip", "parachute", "parrot", "passport", "peanut", "pear", "peas", "pencil", "penguin", "piano", "pickup truck", "picture frame", "pig", "pillow", "pineapple", "pizza", "pliers", "police car", "pond", "pool", "popsicle", "postcard", "potato", "power outlet", "purse", "rabbit", "raccoon", "radio", "rain", "rainbow", "rake", "remote control", "rhinoceros", "rifle", "river", "roller coaster", "rollerskates", "sailboat", "sandwich", "saw", "saxophone", "school bus", "scissors", "scorpion", "screwdriver", "sea turtle", "see saw", "shark", "sheep", "shoe", "shorts", "shovel", "sink", "skateboard", "skull", "skyscraper", "sleeping bag", "smiley face", "snail", "snake", "snorkel", "snowflake", "snowman", "soccer ball", "sock", "speedboat", "spider", "spoon", "spreadsheet", "square", "squiggle", "squirrel", "stairs", "star", "steak", "stereo", "stethoscope", "stitches", "stop sign", "stove", "strawberry", "streetlight", "string bean", "submarine", "suitcase", "sun", "swan", "sweater", "swing set", "sword", "syringe", "t - shirt", "table", "teapot", "teddy - bear", "telephone", "television", "tennis racquet", "tent", "tiger", "toaster", "toe", "toilet", "tooth", "toothbrush", "toothpaste", "tornado", "tractor", "traffic light", "train", "tree", "triangle", "trombone", "truck", "trumpet", "umbrella", "underwear", "van", "vase", "violin", "washing machine", "watermelon", "waterslide", "whale", "wheel", "windmill", "wine bottle", "wine glass", "wristwatch", "yoga", "zebra", "zigzag" };

	AllClasses.Append(classinit);
}

UMain_sketch_recognize::~UMain_sketch_recognize()
{
}


TArray<FVector> UMain_sketch_recognize::DataProcess(const TArray<FVector> stroke_data)
{
	TArray<FVector> Processed_Stroke;
	if (stroke_data.IsEmpty())
	{
		UE_LOG(LogTemp, Warning, TEXT("No shape detected"));
		MyErrmsg = "No shape detected";
		return Processed_Stroke;
	}
	TArray<FVector> Normalized_stroke = NormalizeStroke3(stroke_data);
	if (Normalized_stroke.IsEmpty())
	{
		UE_LOG(LogTemp, Warning, TEXT("Please do not draw a single line"));
		MyErrmsg = "Please do not draw a single line";
		return Processed_Stroke;
	}

    int32 len_stroke = Normalized_stroke.Num();
    if (Normalized_stroke[len_stroke - 2][2] == 1) {    // ��������ڶ�����pen=1��ɾ�����һ��Ԫ��
        Normalized_stroke.RemoveAt(len_stroke - 1);
    };


    TArray<FVector> Normalized_stroke_clean = remove_neighboring_duplicates(Normalized_stroke);


    TArray<FVector> stroke_100Point = sample_to_N_point(Normalized_stroke_clean, 100);

    TArray<FVector> stroke_100Point_0to1;
    for (int i = 0; i < stroke_100Point.Num(); i++) {
        double x = stroke_100Point[i].X / 256;
        double y = stroke_100Point[i].Y / 256;
        double z = stroke_100Point[i].Z;

        stroke_100Point_0to1.Add(FVector(x, y, z));
    }

    Processed_Stroke = stroke_100Point_0to1;
    return Processed_Stroke;
}


TArray<FVector> UMain_sketch_recognize::NormalizeStroke3(TArray<FVector> stroke_data, double canvas_long_side_size, double scale_factor)
{
    double min_x = stroke_data[0][0];
    double max_x = 0;
    double min_y = stroke_data[0][1];
    double max_y = 0;

    for (int i = 0; i < stroke_data.Num(); i++) {
        min_x = std::min(min_x, stroke_data[i][0]);
        max_x = std::max(max_x, stroke_data[i][0]);
        min_y = std::min(min_y, stroke_data[i][1]);
        max_y = std::max(max_y, stroke_data[i][1]);
    }

    double width = max_x - min_x;
    double height = max_y - min_y;
    if (height <= 0 || width <= 0) {
        return TArray<FVector>();
    }

    double aspect_ratio = width / height;
    double scale_size = canvas_long_side_size * scale_factor;
    double target_width = std::min(scale_size, aspect_ratio * scale_size);
    double target_height = std::min(scale_size, (1 / aspect_ratio) * scale_size);

    double scale_x = target_width / width;
    double scale_y = target_height / height;

    double translate_x = (canvas_long_side_size - target_width) / 2;
    double translate_y = (canvas_long_side_size - target_height) / 2;

    TArray<FVector> normalized_stroke;
    for (int i = 0; i < stroke_data.Num(); i++) {
        double x = ((stroke_data[i][0] - min_x) * scale_x) + translate_x;
        double y = ((stroke_data[i][1] - min_y) * scale_y) + translate_y;
        double z = stroke_data[i][2];

        normalized_stroke.AddUnique(FVector(x, y, z));
    }

    return normalized_stroke;
}


TArray<FVector> UMain_sketch_recognize::remove_neighboring_duplicates(TArray<FVector> stroke_data)
{
    TArray<FVector> NewStroke;
    TSet<int32> ToRemove;
    int32 Length = stroke_data.Num();

    int32 i = 0;
    while (i < Length)
    {
        if (stroke_data[i].Z == 1)
        {
            double CurrentX = stroke_data[i][0];
            double CurrentY = stroke_data[i][1];

            int32 LeftIndex = i - 1;
            while (LeftIndex >= 0 && stroke_data[LeftIndex][0] == CurrentX && stroke_data[LeftIndex][1] == CurrentY)
            {
                ToRemove.Add(LeftIndex);
                LeftIndex--;
            }

            int32 RightIndex = i + 1;
            while (RightIndex < Length && stroke_data[RightIndex][0] == CurrentX && stroke_data[RightIndex][1] == CurrentY)
            {
                ToRemove.Add(RightIndex);
                RightIndex++;
            }

            i = RightIndex;
        }
        else
        {
            i++;
        }
    }

    for (int32 Index = 0; Index < Length; Index++)
    {
        if (!ToRemove.Contains(Index))
        {
            NewStroke.Add(stroke_data[Index]);
        }
    }

    return NewStroke;
}


TArray<FVector> UMain_sketch_recognize::sample_to_N_point(TArray<FVector> strokeData, int32 N)
{
    auto pldist = [](const FVector& point, const FVector& start, const FVector& end) {
        float x1 = start.X, y1 = start.Y;
        float x2 = end.X, y2 = end.Y;
        float x0 = point.X, y0 = point.Y;

        float distance;
        if (x1 == x2)
        {
            distance = FMath::Abs(x0 - x1);
        }
        else
        {
            float k = (y2 - y1) / (x2 - x1);
            float b = y1 - k * x1;
            distance = FMath::Abs(k * x0 - y0 + b) / FMath::Sqrt(k * k + 1);
        }

        return distance;
    };

    auto rdp_iter = [&pldist](const TArray<FVector>& M, const TArray<TPair<int32, int32>>& stk) {
        int32 point_num = M.Num();
        TArray<float> dists;
        dists.Init(1000.0f, point_num);

        TArray<TPair<int32, int32>> stack = stk;

        while (stack.Num() > 0)
        {
            TPair<int32, int32> current = stack.Pop();
            int32 start_index = current.Key;
            int32 last_index = current.Value;

            float dmax = 0.0f;
            int32 index = start_index;

            for (int32 i = index + 1; i < last_index; ++i)
            {
                float d = pldist(M[i], M[start_index], M[last_index]);
                dists[i] = d;
                if (d > dmax)
                {
                    index = i;
                    dmax = d;
                }
            }

            if (dmax > 0.0f)
            {
                stack.Add(TPair<int32, int32>(start_index, index));
                stack.Add(TPair<int32, int32>(index, last_index));
            }
        }

        return dists;
    };

    auto process_loop = [](TArray<FVector>& sketch, const TArray<TPair<int32, int32>>& idxs) {
        for (const TPair<int32, int32>& pair : idxs)
        {
            int32 start = pair.Key;
            int32 end = pair.Value;
            if (sketch[start].Equals(sketch[end], 0.001f))
            {
                sketch[end].Y += 0.001f;
            }
        }
    };

    TArray<int32> end_idxs;
    for (int32 i = 0; i < strokeData.Num(); ++i)
    {
        if (strokeData[i].Z == 1)
        {
            end_idxs.Add(i);
        }
    }

    if (strokeData.Num() < N)
    {
		UE_LOG(LogTemp, Warning, TEXT("The sketch is too small or draw too fast, can't recognize"));
		flag_GetXAndSparseMatrix = false;
		MyErrmsg = "The sketch is too small or draw too fast, can't recognize";
		return TArray<FVector>();
    }

    if (end_idxs.Num() * 2 > N)
    {
		UE_LOG(LogTemp, Warning, TEXT("The sketch is too complexity or too many points"));
		MyErrmsg = "The sketch is too complexity or too many points";
        flag_GetXAndSparseMatrix = false;
        return TArray<FVector>();
    }

    TArray<int32> start_idxs;
    for (int32 i = 0; i < end_idxs.Num() - 1; ++i)
    {
        start_idxs.Add(end_idxs[i] + 1);
    }
    start_idxs.Insert(0, 0);

    TArray<TPair<int32, int32>> idxs;
    for (int32 i = 0; i < end_idxs.Num(); ++i)
    {
        idxs.Add(TPair<int32, int32>(start_idxs[i], end_idxs[i]));
    }

    TArray<FVector> sketch = strokeData;
    process_loop(sketch, idxs);

    TArray<float> dists = rdp_iter(sketch, idxs);

    TArray<int32> sortedIndices;
    for (int32 i = 0; i < dists.Num(); ++i)
    {
        sortedIndices.Add(i);
    }
    sortedIndices.Sort([&dists](int32 A, int32 B) { return dists[A] > dists[B]; });

    TArray<int32> topNIndices;
    for (int32 i = 0; i < N; i++)
    {
        topNIndices.Add(sortedIndices[i]);
    }
    topNIndices.Sort();

    TArray<FVector> newSketchArray;
    for (int32 index : topNIndices)
    {
        newSketchArray.Add(sketch[index]);
    }

    return newSketchArray;
}


TArray<FVector2D> GenerateLists(const TArray<int32>& lst)
{
    int32 n = lst.Num();
    TArray<FVector2D> result;

    TArray<int32> sublist = lst;
    sublist.RemoveAt(n - 1);

    int32 firstItem = sublist[0];
    int32 lastItem = sublist[sublist.Num() - 1];
    result.Add(FVector2D(firstItem - 1, firstItem));

    sublist.RemoveAt(0);
    for (int32 i = 0; i < sublist.Num() / 2; ++i)
    {
        result.Add(FVector2D(sublist[2 * i], sublist[2 * i + 1]));
    }

    result.Add(FVector2D(lastItem - 1, lastItem));

    return result;
}


TArray<FVector2D> SplitList(const TArray<int32>& listStart, const TArray<int32>& listEnd)
{
    TArray<int32> gap;
    for (int32 i = 0; i < (listEnd.Num() - 2) / 2; ++i)
    {
        int32 start = listStart[2 * i + 1];
        int32 end = listEnd[2 * i + 2];
        if (end != (start + 1))
        {
            gap.Add(2 * i + 2);
        }
    }

    TArray<TArray<int32>> sublistListEnd;
    int32 start = 0;
    for (int32 index : gap)
    {
        TArray<int32> sublist;
        for (int32 i = start; i < index; ++i)
        {
            sublist.Add(listEnd[i]);
        }
        sublistListEnd.Add(sublist);
        start = index;
    }

    TArray<int32> sublist;
    for (int32 i = start; i < listEnd.Num(); ++i)
    {
        sublist.Add(listEnd[i]);
    }
    sublistListEnd.Add(sublist);

    TArray<FVector2D> out;
    for (const TArray<int32>& split : sublistListEnd)
    {
        out.Append(GenerateLists(split));
    }

    return out;
}


void UMain_sketch_recognize::GetXAndSparseMatrix(const TArray<FVector>& strokeData, TArray<FVector2D>& coordinates, TArray<FVector2D>& edgeIndexDigraph) {
    int32 numPoints = strokeData.Num();
    coordinates.Empty();
    TArray<int32> states;
    TArray<int32> offsetFlags;

    for (int32 i = 0; i < numPoints; ++i) {
        coordinates.Add(FVector2D(strokeData[i].X, strokeData[i].Y));
        states.Add(strokeData[i].Z);
    }

    for (int32 i = 0; i < states.Num() - 1; ++i) {
        offsetFlags.Add(static_cast<int32>(!states[i]));
    }

    TArray<int32> sparseMatrixEven;
    TArray<int32> sparseMatrixOdd;

    for (int32 i = 0; i < numPoints - 1; ++i) {
        if (offsetFlags[i] != 0) {
            sparseMatrixEven.Add(i);
            sparseMatrixEven.Add(i + 1);
            sparseMatrixOdd.Add(i + 1);
            sparseMatrixOdd.Add(i);
        }
    }

    edgeIndexDigraph = SplitList(sparseMatrixEven, sparseMatrixOdd);
}


void UMain_sketch_recognize::GetONNXModel(TUniquePtr<UE::NNE::IModelInstanceCPU>& ModelInstance)
{

    TObjectPtr<UNNEModelData> ModelData = LoadObject<UNNEModelData>(GetTransientPackage(), TEXT("/sketch_recognize/onnx_sage_x-100-2_index-2-100-sim.onnx_sage_x-100-2_index-2-100-sim"));
    TWeakInterfacePtr<INNERuntimeCPU> Runtime = UE::NNE::GetRuntime<INNERuntimeCPU>(FString("NNERuntimeORTCpu"));
    ModelInstance = Runtime->CreateModel(ModelData)->CreateModelInstance();

    TConstArrayView<UE::NNE::FTensorDesc> InputTensorDescs = ModelInstance->GetInputTensorDescs();
    UE::NNE::FSymbolicTensorShape SymbolicInputTensorShape_X = InputTensorDescs[0].GetShape();
    UE::NNE::FSymbolicTensorShape SymbolicInputTensorShape_Edge = InputTensorDescs[1].GetShape();
    TArray<UE::NNE::FTensorShape> InputTensorShapes = {
        UE::NNE::FTensorShape::MakeFromSymbolic(SymbolicInputTensorShape_X),
        UE::NNE::FTensorShape::MakeFromSymbolic(SymbolicInputTensorShape_Edge)
    };

    ModelInstance->SetInputTensorShapes(InputTensorShapes);

    InputBinding_X_SizeInBytes = InputTensorShapes[0].Volume() * InputTensorDescs[0].GetElemByteSize();
    InputBinding_Edge_SizeInBytes = InputTensorShapes[1].Volume() * InputTensorDescs[1].GetElemByteSize();

    TConstArrayView<UE::NNE::FTensorDesc> OutputTensorDescs = ModelInstance->GetOutputTensorDescs();
    UE::NNE::FSymbolicTensorShape SymbolicOutputTensorShape_Score = OutputTensorDescs[0].GetShape();
    UE::NNE::FSymbolicTensorShape SymbolicOutputTensorShape_Predict_Lable = OutputTensorDescs[1].GetShape();
    TArray<UE::NNE::FTensorShape> OutputTensorShapes = {
        UE::NNE::FTensorShape::MakeFromSymbolic(SymbolicOutputTensorShape_Score),
        UE::NNE::FTensorShape::MakeFromSymbolic(SymbolicOutputTensorShape_Predict_Lable)
    };

    OutputBinding_Score_SizeInBytes = OutputTensorShapes[0].Volume() * OutputTensorDescs[0].GetElemByteSize();
    OutputBinding_Predict_lable_SizeInBytes = OutputTensorShapes[1].Volume() * OutputTensorDescs[1].GetElemByteSize();

}


void UMain_sketch_recognize::GetTensor(const TArray<FVector2D>& coordinates, TArray<FVector2D>& edgeIndexDigraph,
    TArray<UE::NNE::FTensorBindingCPU>& Inputs,
    TArray<UE::NNE::FTensorBindingCPU>& Outputs)
{
    Inputs.SetNum(2);

    for (const FVector2D& coord : coordinates) {
        InputData_X.Add((float)coord.X);
        InputData_X.Add((float)coord.Y);
    }

    Inputs[0].Data = InputData_X.GetData();
    Inputs[0].SizeInBytes = InputBinding_X_SizeInBytes;

    TArray<int64> InputData_Edge_Index_End;
    for (const FVector2D& edgeIndex : edgeIndexDigraph) {
        InputData_Edge_Index.Add((int64)edgeIndex.X);
        InputData_Edge_Index_End.Add((int64)edgeIndex.Y);
    }
    InputData_Edge_Index.Append(InputData_Edge_Index_End);

    Inputs[1].Data = InputData_Edge_Index.GetData();
    Inputs[1].SizeInBytes = InputBinding_Edge_SizeInBytes;


    // Outputs
    OutputData_Score.SetNumZeroed(344);
    OutputData_Predict_Lable.SetNumZeroed(1);

    Outputs.SetNum(2);
    Outputs[0].Data = OutputData_Score.GetData();
    Outputs[0].SizeInBytes = OutputBinding_Score_SizeInBytes;
    Outputs[1].Data = OutputData_Predict_Lable.GetData();
    Outputs[1].SizeInBytes = OutputBinding_Predict_lable_SizeInBytes;

}


void UMain_sketch_recognize::RunClassification(const TArray<FVector> stroke_data, int& Predict_Lable, FString& Errmsg)
{

    TUniquePtr<UE::NNE::IModelInstanceCPU> ModelInstance;
    GetONNXModel(ModelInstance);

    TArray<FVector> Processed_Stroke = DataProcess(stroke_data);

    TArray<FVector2D> coordinates;
    TArray<FVector2D> edgeIndexDigraph;
    if (flag_GetXAndSparseMatrix && !Processed_Stroke.IsEmpty())
    {
        GetXAndSparseMatrix(Processed_Stroke, coordinates, edgeIndexDigraph);

        TArray<UE::NNE::FTensorBindingCPU> Inputs;
        TArray<UE::NNE::FTensorBindingCPU> Outputs;
        GetTensor(coordinates, edgeIndexDigraph, Inputs, Outputs);

        ModelInstance->RunSync(Inputs, Outputs);
        if (!OutputData_Predict_Lable.IsEmpty())
        {
            Predict_Lable = OutputData_Predict_Lable[0];
            UE_LOG(LogTemp, Log, TEXT("Predict_Lable:%d"), Predict_Lable);
            UE_LOG(LogTemp, Log, TEXT("model reasoning success"));
        }
        else {
            Predict_Lable = -1;
			UE_LOG(LogTemp, Warning, TEXT("reasoning failed, OutputData_Predict_Lable.len:%d"), OutputData_Predict_Lable.Num());
			Errmsg = "reasoning failed by unknown cause.";
        }
    }
    else {
        Predict_Lable = -1;
        UE_LOG(LogTemp, Warning, TEXT("model reasoning failed"));
		Errmsg = MyErrmsg;
    }

}


void UMain_sketch_recognize::GetScope(const int ClassIndex, float& Scope)
{

    float Log_Scope = OutputData_Score[ClassIndex];

    Scope = FMath::Exp(Log_Scope);

}
