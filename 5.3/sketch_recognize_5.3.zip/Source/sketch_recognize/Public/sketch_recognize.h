//Copyright (c) Code By HelloJXY. All rights reserved. Date : 2024/6/20

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"


class Fsketch_recognizeModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};
