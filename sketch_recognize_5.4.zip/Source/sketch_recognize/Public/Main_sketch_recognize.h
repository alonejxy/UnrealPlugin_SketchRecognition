//Copyright (c) Code By HelloJXY. All rights reserved. Date : 2024/6/20

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "NNE.h"
#include "NNEModelData.h"
#include "NNERuntimeCPU.h"

#include "Main_sketch_recognize.generated.h"

/**
 *
 */
UCLASS(Blueprintable, classGroup = (Sketch))
class SKETCH_RECOGNIZE_API UMain_sketch_recognize : public UObject
{
	GENERATED_BODY()
public:
	UMain_sketch_recognize();
	~UMain_sketch_recognize();

	UFUNCTION(BlueprintCallable, Category = "sketch_recognize")
		void RunClassification(const TArray<FVector> stroke_data, int& Predict_Lable, FString& Errmsg);

	UFUNCTION(BlueprintCallable, Category = "sketch_recognize")
		void GetScope(const int ClassIndex, float& Scope);

	UPROPERTY(BlueprintReadOnly, Category = "sketch_recognize")
		TArray<FString> AllClasses;
private:

	TArray<FVector> DataProcess(const TArray<FVector> stroke_data);

	TArray<FVector> NormalizeStroke3(TArray<FVector> stroke_data, double canvas_long_side_size = 256.0, double scale_factor = 0.9);

	TArray<FVector> remove_neighboring_duplicates(TArray<FVector> stroke_data);

	bool flag_GetXAndSparseMatrix = true;

	TArray<FVector> sample_to_N_point(TArray<FVector> strokeData, int32 N = 100);

	void GetXAndSparseMatrix(const TArray<FVector>& strokeData, TArray<FVector2D>& coordinates, TArray<FVector2D>& edgeIndexDigraph);

	void GetONNXModel(TSharedPtr<UE::NNE::IModelInstanceCPU>& ModelInstance);

	uint64 InputBinding_X_SizeInBytes;
	uint64 InputBinding_Edge_SizeInBytes;
	uint64 OutputBinding_Score_SizeInBytes;
	uint64 OutputBinding_Predict_lable_SizeInBytes;

	TArray<float> InputData_X;
	TArray<int64> InputData_Edge_Index;

	TArray<float> OutputData_Score;
	TArray<int64> OutputData_Predict_Lable;

	void GetTensor(const TArray<FVector2D>& coordinates, TArray<FVector2D>& edgeIndexDigraph, TArray<UE::NNE::FTensorBindingCPU>& Inputs, TArray<UE::NNE::FTensorBindingCPU>& Outputs);

	FString MyErrmsg;

};
